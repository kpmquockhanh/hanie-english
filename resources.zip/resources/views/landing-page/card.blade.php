
<section id="sec">
    <h3 class="header-title">Các levels để giao tiếp thành thạo</h3>
    <ul>
        <li>
            <span class="fa fa-book"></span>

            <h3>Level 1: STARTERS</h3>
            <p>
                -	40 buổi học bao gồm 4 bài test.
            </p>
            <p>
                -	Các mẫu câu đơn giản, ôn tập lại với 6 thì cơ bản.
            </p>
            <p>
                -	Với hơn 85 cấu trúc câu.
            </p>
            <p>
                -	15 bài phát âm.
            </p>
            <p>
                -	Hơn 200 từ vựng.
            </p>
        </li>
        <li>
            <span class="fa fa-book"></span>
            <h3>Level 2: Movers</h3>
            <p>-	Hơn 30 buổi học.</p>
            <p>-	Các tình huống giao tếp gần gũi trong đời sống, luyện là chỉnh âm theo phương pháp role – play.</p>
            <p>-	150 cấu trúc câu.</p>
            <p>-	300 từ vựng.</p>
        </li>
        <li>
            <span class="fa fa-book"></span>
            <h3>Level 3: Advanced</h3>
            <p>-	Các từ ngữ chuyên ngành.</p>
            <p>-	Các chủ đề liên quan đến khoa học và cuộc sống.</p>
            <p>-    Gần 10 chủ đề lớn, phát triển toàn diện 4 kỹ năng: LISTENING, SPEAKING, WRITING, READING nhờ 140 bài giảng</p>
        </li>

    </ul>
</section>