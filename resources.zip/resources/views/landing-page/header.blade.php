<!-- header
================================================== -->
<header>


    <!--<div class="header-logo">-->
    <!--<a href="">Hanie English</a>-->
    <!--</div>-->

    <a id="header-menu-trigger" href="#0">
        <span class="header-menu-text">Menu</span>
        <span class="header-menu-icon"></span>
    </a>

    <nav id="menu-nav-wrap">

        <a href="#0" class="close-button" title="close"><span>Close</span></a>

        <h3>Hanie English.</h3>

        <ul class="nav-list">
            <li class="current"><a class="smoothscroll" href="#home" title="">Home</a></li>
            <li><a class="smoothscroll" href="#about" title="">Giới Thiệu</a></li>
            <li><a class="smoothscroll" href="#services" title="">Mô Hình</a></li>
            <li><a class="smoothscroll" href="#courses" title="">Khóa Học</a></li>
            <!--<li><a class="smoothscroll" href="#contact" title="">Contact</a></li>-->
        </ul>

        <ul class="header-social-list">
            <li>
                <a href="https://www.facebook.com/Ngh%E1%BB%87-Thu%E1%BA%ADt-Chinh-Ph%E1%BB%A5c-Ti%E1%BA%BFng-Anh-1839176996210179/"><i class="fa fa-facebook-square"></i></a>
            </li>
            {{--<li>--}}
                {{--<a href="#"><i class="fa fa-twitter"></i></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a href="#"><i class="fa fa-instagram"></i></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a href="#"><i class="fa fa-behance"></i></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a href="#"><i class="fa fa-dribbble"></i></a>--}}
            {{--</li>--}}
        </ul>

    </nav>  <!-- end #menu-nav-wrap -->

</header> <!-- end header -->