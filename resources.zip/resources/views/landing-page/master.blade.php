<!DOCTYPE html>
<!--[if IE 8 ]>
<html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]>
<html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html class="no-js" lang="en"> <!--<![endif]-->
<head>
    @include('landing-page.head')
</head>

<body id="top">

@include('landing-page.header')

@include('landing-page.home')

@include('landing-page.about')

@include('landing-page.services')

@include('landing-page.general')

@include('landing-page.courses2')

@include('landing-page.courses')

{{--@include('landing-page.portfolio')--}}

{{--@include('landing-page.testimonials')--}}

{{--@include('landing-page.clients')--}}

@include('landing-page.footer')

<div id="preloader">
    <div id="loader"></div>
</div>

@include('landing-page.scripts')

</body>

</html>