<!-- stats
================================================== -->
<section id="clients">

    <div class="row animate-this">
        <div class="col-twelve">

            <div class="client-lists owl-carousel">
                <div><img src="images/clients/mozilla.png" alt=""></div>
                <div><img src="images/clients/bower.png" alt=""></div>
                <div><img src="images/clients/codepen.png" alt=""></div>
                <div><img src="images/clients/envato.png" alt=""></div>
                <div><img src="images/clients/firefox.png" alt=""></div>
                <div><img src="images/clients/grunt.png" alt=""></div>
                <div><img src="images/clients/evernote.png" alt=""></div>
                <div><img src="images/clients/github.png" alt=""></div>
                <div><img src="images/clients/joomla.png" alt=""></div>
                <div><img src="images/clients/jQuery.png" alt=""></div>
                <div><img src="images/clients/wordpress.png" alt=""></div>
            </div>

        </div> <!-- end col-twelve -->
    </div> <!-- end row -->

</section>
<!-- end clients -->