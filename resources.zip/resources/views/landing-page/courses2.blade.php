<!-- about
================================================== -->
<style>
    /*
 CSS for the main interaction
*/
    .tabset > input[type="radio"] {
        position: absolute;
        left: -200vw;
    }

    .tabset .tab-panel {
        display: none;
    }

    .tabset > input:first-child:checked ~ .tab-panels > .tab-panel:first-child,
    .tabset > input:nth-child(3):checked ~ .tab-panels > .tab-panel:nth-child(2),
    .tabset > input:nth-child(5):checked ~ .tab-panels > .tab-panel:nth-child(3),
    .tabset > input:nth-child(7):checked ~ .tab-panels > .tab-panel:nth-child(4),
    .tabset > input:nth-child(9):checked ~ .tab-panels > .tab-panel:nth-child(5),
    .tabset > input:nth-child(11):checked ~ .tab-panels > .tab-panel:nth-child(6) {
        display: block;
    }

    /*
     Styling
    */
    body {
        font: 16px/1.5em "Overpass", "Open Sans", Helvetica, sans-serif;
        color: #333;
        font-weight: 300;
    }

    .tabset > label {
        position: relative;
        display: inline-block;
        padding: 15px 15px 25px;
        border: 1px solid transparent;
        border-bottom: 0;
        cursor: pointer;
        font-weight: 600;
    }

    .tabset > label::after {
        content: "";
        position: absolute;
        left: 15px;
        bottom: 10px;
        width: 22px;
        height: 4px;
        background: #8d8d8d;
    }

    .tabset > label:hover,
    .tabset > input:focus + label {
        color: #06c;
    }

    .tabset > label:hover::after,
    .tabset > input:focus + label::after,
    .tabset > input:checked + label::after {
        background: #06c;
    }

    .tabset > input:checked + label {
        border-color: #ccc;
        border-bottom: 1px solid #fff;
        margin-bottom: -1px;
    }

    .tab-panel {
        padding: 30px 0;
        border-top: 1px solid #ccc;
    }

    .tabset {
        max-width: 65em;
    }
</style>
<section id="courses">
    <div class="row">
        <div class="tabset">
            <!-- Tab 1 -->
            <input type="radio" name="tabset" id="tab1" aria-controls="h1" checked>
            <label for="tab1">Hanie 01</label>
            <!-- Tab 2 -->
            <input type="radio" name="tabset" id="tab2" aria-controls="h2">
            <label for="tab2">Hanie 02</label>
            <input type="radio" name="tabset" id="tab3" aria-controls="h3">
            <label for="tab3">Hanie 03</label>

            <div class="tab-panels">
                <section id="h1" class="tab-panel text-left">
                    <h2>Hanie 01</h2>
                    <p>Nhận mặt chữ</p>
                    <p>Nắm được kiến thức giao tiếp cơ bản (kĩ năng, hình thành phản xạ)</p>
                    <p>Làm quen với bảng phiên âm cơ bản, làm quen và mở khẩu hình</p>
                </section>
                <section id="h2" class="tab-panel text-left">
                    <h2>Hanie 02</h2>
                    <p>Tiếp xúc với nhiều tình huống giao tiếp khác nhau, hình thành vốn vựng cơ bản qua hơn 20 chủ đề quen thuộc</p>
                    <p>Vận dụng kĩ năng mở khẩu hình, làm quen với các cấu trúc trong giao tiếp tiếng anh</p>
                    <p>Tăng khả năng nói nhờ 20 bài FREETALKS trong quá trình học.</p>
                </section>
                <section id="h3" class="tab-panel text-left">
                    <h2>Hanie 03</h2>
                    <p>Nắm được nhiều cáu trúc khó hơn cùng lượng từ vụng phong phú và tăng kĩ năng vận dụng từ vựng (tương đương TOEIC 600)</p>
                    <p>Nắm chắc nhiều kiến thức cơ bản về các vấn đề trong cuộc sống nhờ lượng lớn từ vụng chuyên ngành theo chủ đề</p>
                    <p>Tăng khả năng vẫn dụng ngữ pháp</p>
                    <p>Tăng khả năng thuyết trình tiếng anh, vận dụng từ vựng (Tương đương TOEIC 750 và IELTS speaking 6.5)</p>
                </section>
            </div>
        </div>
    </div>

</section>