<!-- about
================================================== -->
<section id="level">
    @include('landing-page.card')
</section> <!-- end about -->