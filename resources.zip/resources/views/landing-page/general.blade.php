<!-- about
================================================== -->
<section id="courses" class="text-left">
    <h3 class="header-title text-center">CHƯƠNG TRÌNH ĐÀO TẠO TỔNG QUÁT</h3>
    
    <h5 class="text-left row font-30">Luyện thi PET, KET, TOEIC</h5>
    <dl class="row text-left">
        <dt><strong class="font-20">Mô hình chuẩn châu âu: từ STARTERS, MOVERS, FLYERS
TOEIC VỚI 4 KỸ NĂNG
TỪ 350 ĐẾN 750 - 800 TRONG VÒNG 3 ĐẾN 6 THÁNG</strong></dt>
       
    </dl>

    <h5 class="text-left row font-30">Giảng viên</h5>
    <dl class="row text-left">
        <dd>Giảng viên nhiệt tình, luôn theo sát học viên trong từng buổi học, và trong suốt khóa học</dd>
        <dd>Tất cả các giảng viên đều được đào tạo bài bản chuyên nghiệp</dd>
        <dd>Có kỹ năng sư phạm</dd>
        <dd>Có kinh nghiệm giảng dạy - Có bằng Toeic, IELTS, B2, TESOL</dd>
        <dd>Được đào tạo từ khoa ngoại ngữ của các trường đại học: Đại học ngoại ngữ Hà Nội, Đại học Thương Mại,...</dd>
    </dl>
    
    <h5 class="text-left row font-30">Phương pháp</h5>
    <dl class="row text-left">
        <dt><strong class="font-20">Phương pháp luyện nghe</strong></dt>
        <dd>Được chia thành 3 giai đoạn : Pre-listening, While-listening, Post-listening</dd>
        <dd>Với 3 bước này sẽ hỗ trợ học viên nghe hiểu sâu và bắt được nghĩa của bài 1 cách rõ ràng nhất, và có khả năng diễn đạt ý tưởng của câu chuyện theo cách hiểu của bản thân</dd>
        <dt><strong class="font-20">Phương pháp dạy “SPEAKING”</strong></dt>
        <dd>Role-play: Học viên và giáo viên đóng vai nhân vật trong một ngữ cảnh nhất định để luyện tập kĩ năng nói. Học viên được cung cấp từ mới, cấu trúc câu để hiểu tường tận bài nói, chỉnh sửa ngữ âm giúp học viên nói đúng ngữ điệu.</dd>
        <dd>Sử dụng tiếng anh tối đa để giao tiếp trong lớp học lợi ích của việc sử dụng tiếng anh trong lớp: Giúp học viên luyện nghe và nói một cách trôi chảy, tự nhiên nhất có thể</dd>
        <dd>Đưa cho học sinh cảm giác tiếng anh là một ngôn ngữ để giao tiếp thực sự chứ không phải là một ngôn ngữ trên sách vở, hay là học vẹt</dd>
    </dl>
</section> <!-- end about -->